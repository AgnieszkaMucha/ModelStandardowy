#include <TGClient.h> 
#include <TCanvas.h>  
#include <TF1.h> 
#include <TRandom.h> 
#include <TGButton.h> 
#include <TGFrame.h> 
#include <TRootEmbeddedCanvas.h> 
#include <TGNumberEntry.h> 
#include <RQ_OBJECT.h> 

#include <iostream>


class MyMainFrame { 
	RQ_OBJECT("MyMainFrame") 
	private: 
		TGMainFrame         *fMain; 
		TRootEmbeddedCanvas *fEcanvas; 
		
		TGDoubleHSlider * hDsliderX;
		TGDoubleHSlider * hDsliderY;
		
		TGNumberEntry *fNumber_dm;
		TGNumberEntry *fNumber_x;
		TGNumberEntry *fNumber_y;
		
		TGTextEntry *textName;
	public: 
		MyMainFrame(const TGWindow *p, UInt_t w, UInt_t h); 
		virtual ~MyMainFrame(); 
	
	private:
		// Parameters:
		Double_t dm;
		Double_t x;
		Double_t y;
		Double_t sG;
		Double_t dG;
		
		// Range:
		Double_t x_0;
		Double_t x_k;
		Double_t y_0;
		Double_t y_k;
		
		TF1 * fp;
		TF1 * fm;
		
		TCanvas * can;
		TH2D * back;
		TLegend * legend;

	private:
		void InitializeParameters();
		

		
	public:
		void SetRangeX();
		void SetRangeY();
		void SetCanName();
		void Change_dm();
		void Change_x();
		void Change_y();	
	
		void SetValues(); 	
		void DrawPlot(); 	
		void PrintPlot(); 	

};             

MyMainFrame::MyMainFrame(const TGWindow *window, UInt_t width, UInt_t height){ 
	InitializeParameters();

	fMain = new TGMainFrame(window, width, height); 

	TGCompositeFrame *topFrame = new TGCompositeFrame(fMain, width, height, kHorizontalFrame );		
	// Create canvas widget 
	fEcanvas = new TRootEmbeddedCanvas("Ecanvas",fMain,0.8*width,0.8*height); 
	topFrame->AddFrame(fEcanvas, new TGLayoutHints(kLHintsLeft, 10,10,10,1));  

	// Create a vertical frame widget with parameters
	TGGroupFrame *hParametersFrame = new TGGroupFrame(fMain,"Parameters");
		TGLabel * fLabel_dm = new TGLabel(hParametersFrame, "dm");
		hParametersFrame->AddFrame(fLabel_dm, new TGLayoutHints(kLHintsTop | kLHintsExpandX, 5, 5, 5, 5));
		fNumber_dm = new TGNumberEntry(hParametersFrame, dm, 9,901, TGNumberFormat::kNESReal, TGNumberFormat::kNEANonNegative, TGNumberFormat::kNELLimitMinMax, 0, 99999);
		fNumber_dm->Connect("ValueSet(Long_t)","MyMainFrame",this,"Change_dm()"); 	
		fNumber_dm->SetLogStep();
		hParametersFrame->AddFrame(fNumber_dm, new TGLayoutHints(kLHintsTop | kLHintsExpandX, 5, 5, 5, 5));
		TGLabel * fLabel_x = new TGLabel(hParametersFrame, "x");
		hParametersFrame->AddFrame(fLabel_x, new TGLayoutHints(kLHintsTop | kLHintsExpandX, 5, 5, 5, 5));
		fNumber_x = new TGNumberEntry(hParametersFrame,  x, 9,902, TGNumberFormat::kNESReal, TGNumberFormat::kNEANonNegative, TGNumberFormat::kNELLimitMinMax, 0, 99999);
		fNumber_x->Connect("ValueSet(Long_t)","MyMainFrame",this,"Change_x()"); 
		fNumber_x->SetLogStep();
		hParametersFrame->AddFrame(fNumber_x, new TGLayoutHints(kLHintsTop | kLHintsExpandX, 5, 5, 5, 5));
		TGLabel * fLabel_y = new TGLabel(hParametersFrame, "y");
		hParametersFrame->AddFrame(fLabel_y, new TGLayoutHints(kLHintsTop | kLHintsExpandX, 5, 5, 5, 5));
		fNumber_y = new TGNumberEntry(hParametersFrame,  y, 9,903, TGNumberFormat::kNESReal, TGNumberFormat::kNEANonNegative, TGNumberFormat::kNELLimitMinMax, 0, 10);
		fNumber_y->SetLogStep();
		fNumber_y->Connect("ValueSet(Long_t)","MyMainFrame",this,"Change_y()"); 
		hParametersFrame->AddFrame(fNumber_y, new TGLayoutHints(kLHintsTop | kLHintsExpandX, 5, 5, 5, 5));
		hParametersFrame->Resize(0.2*width,0.8*height);
	topFrame->AddFrame(hParametersFrame, new TGLayoutHints(kLHintsLeft, 10,10,10,1));  
	fMain->AddFrame(topFrame, new TGLayoutHints(kLHintsLeft, 10,10,10,1));  
			
	// Create a horizontal frame widget with axis slider
	TGGroupFrame *hSliderFrame = new TGGroupFrame(fMain, TString::Format("Axis range: x: %5.2lf - %5.2lf,   y: 0.0 - 1.0",x_0,x_k));
		hDsliderX = new TGDoubleHSlider(hSliderFrame,100, kSlider1 | kDoubleScaleBoth,110); 
		hDsliderX->SetRange(x_0,x_k); 
		hDsliderX->SetPosition(x_0,x_k);
		hDsliderX->Connect("PositionChanged()","MyMainFrame",this,"SetRangeX()"); 
		hSliderFrame->AddFrame(hDsliderX, new TGLayoutHints(kLHintsExpandX,5,5,3,4)); 
		hDsliderY = new TGDoubleHSlider(hSliderFrame,100, kSlider1 | kDoubleScaleBoth,110); 
		hDsliderY->SetRange(y_0,y_k); 
		hDsliderY->SetPosition(y_0,y_k);
		hDsliderY->Connect("PositionChanged()","MyMainFrame",this,"SetRangeY()"); 
		hSliderFrame->AddFrame(hDsliderY, new TGLayoutHints(kLHintsExpandX,5,5,3,4)); 
	fMain->AddFrame(hSliderFrame, new TGLayoutHints(kLHintsExpandX, 10,10,10,1));  

	// Create a horizontal frame widget with print button		
	TGGroupFrame *hPrintFrame = new TGGroupFrame(fMain,"Save plot", kHorizontalFrame);
		TGLabel * fLabelName = new TGLabel(hPrintFrame, "File Name:");
		hPrintFrame->AddFrame(fLabelName, new TGLayoutHints(kLHintsLeft , 5, 5, 5, 5));
		textName = new TGTextEntry(hPrintFrame, "Plot");
		hPrintFrame->AddFrame(textName, new TGLayoutHints(kLHintsExpandX,5,5,3,4)); 		
		TGTextButton *print = new TGTextButton(hPrintFrame,"      Save      "); 
		print->Connect("Clicked()","MyMainFrame",this,"PrintPlot()"); 
		hPrintFrame->AddFrame(print, new TGLayoutHints(kLHintsRight,5,5,3,4)); 
		hPrintFrame->Resize(0.5*width,0.0*height);	
	fMain->AddFrame(hPrintFrame, new TGLayoutHints(kLHintsCenterX,2,2,2,2)); 

	// Create a horizontal frame widget with exit button
	TGHorizontalFrame *hExitFrame = new TGHorizontalFrame(fMain,width,0.1*height); 
		TGTextButton *exit = new TGTextButton(hExitFrame,"      Exit      ", "gApplication->Terminate(0)"); 
		hExitFrame->AddFrame(exit, new TGLayoutHints(kLHintsCenterX,5,5,3,4));
	fMain->AddFrame(hExitFrame, new TGLayoutHints(kLHintsCenterX,2,2,2,2)); 	

	// Set a name to the main frame 
	fMain->SetWindowName("Oscilation of kaons"); 
	// Map all subwindows of main frame 
	fMain->MapSubwindows(); 
	// Initialize the layout algorithm 
	fMain->Resize(fMain->GetDefaultSize()); 
	// Map main frame 
	fMain->MapWindow(); 	
	
	
	SetRangeX();
	SetRangeY();
	SetValues();
	DrawPlot();	
	
} 



MyMainFrame::~MyMainFrame() { 
	// Clean up used widgets: frames, buttons, layouthints 
	fMain->Cleanup(); 
	delete fMain; 
} 

void MyMainFrame::InitializeParameters() { 
	//Parameters
	dm = 1;
	x = 10;
	y = 1;	
	sG = dm/x;
	dG = y*sG;	
	// Range:
	x_0=0.0;
	x_k=100.0;
	y_0=0.0;
	y_k=1.0;   
   
	//Functions
   	fp = new TF1("fp", "0.5*TMath::Exp(-[0]*x)*(TMath::CosH(0.5*[1]*x)+TMath::Cos([2]*x))", x_0, x_k);
	fm = new TF1("fm", "0.5*TMath::Exp(-[0]*x)*(TMath::CosH(0.5*[1]*x)-TMath::Cos([2]*x))", x_0, x_k);
	fp->SetLineColor(2);
	fm->SetLineColor(4);	
	fp->SetLineWidth(2);
	fm->SetLineWidth(2);	
	fp->SetNpx(1000);
	fm->SetNpx(1000);
	
	//Background	
	back = new TH2D("background","Oscilation of kaons", 1000, x_0, x_k, 1000, y_0, y_k);
	back->SetStats(0);
	back->GetXaxis()->SetTitle("proper time [ps]");
	back->GetYaxis()->SetTitle("probability");
	back->GetXaxis()->CenterTitle();
	back->GetYaxis()->CenterTitle();	   
	
	legend = new TLegend(0.7,0.6,0.95,0.95);
}

void MyMainFrame::SetRangeX(){
	x_0=hDsliderX->GetMinPosition();
	x_k=hDsliderX->GetMaxPosition();
	
	back->GetXaxis()->SetRangeUser(x_0,x_k);
	DrawPlot();
}
void MyMainFrame::SetRangeY(){
	y_0=hDsliderY->GetMinPosition();
	y_k=hDsliderY->GetMaxPosition();
	
	back->GetYaxis()->SetRangeUser(y_0,y_k);
	DrawPlot();
}

void MyMainFrame::Change_dm(){
	dm = fNumber_dm->GetNumberEntry()->GetNumber();
	SetValues();
	DrawPlot();
}

void MyMainFrame::Change_x(){
	x = fNumber_x->GetNumberEntry()->GetNumber();
	SetValues();
	DrawPlot();	
}
	
void MyMainFrame::Change_y(){
	y = fNumber_y->GetNumberEntry()->GetNumber();
	SetValues();
	DrawPlot();	
}
	
void MyMainFrame::DrawPlot() { 
	back->Draw();
	fp->Draw("SameL");
	fm->Draw("SameL");
	
	legend->Clear();
	legend->SetHeader("The Legend:");
	legend->AddEntry(fp, "Kaons K^{0}", "L");
	legend->AddEntry(fm, "Anitkaons #bar{K^{0}}", "L");
	legend->AddEntry((TObject*)0, "", "");
	legend->AddEntry((TObject*)0, "Parameters:", "");
	legend->AddEntry((TObject*)0, TString::Format("#Deltam = %10.5lf",dm), "");
	legend->AddEntry((TObject*)0, TString::Format("  x   = %10.5lf",x), "");
	legend->AddEntry((TObject*)0, TString::Format("  y   = %10.5lf",y), "");		
	legend->Draw();

	TCanvas *fCanvas = fEcanvas->GetCanvas();     
	fCanvas->cd(); 
	fCanvas->Update(); 
} 

void MyMainFrame::SetValues(){
	sG = dm/x;
	dG = y*sG;		
	
	// [0] - sG // [1] - dG // [2] - dm
	fp->SetParameters( sG, dG, dm);
	fm->SetParameters( sG, dG, dm);	
}

void MyMainFrame::PrintPlot()
{
	TString canName(textName->GetText());
	if( canName.IsNull() ){
		canName = "Plot";
	}
	fEcanvas->GetCanvas()->Print(TString::Format("Plots/%s.png",canName.Data()));
}

void DrawOscilation(){ 
	// Popup the GUI... 
	new MyMainFrame(gClient->GetRoot(),1000,700); 
} 
